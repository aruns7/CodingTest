package com.interview;

public enum FuelType {
    PETROL, DIESEL
}
